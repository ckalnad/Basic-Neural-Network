#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Code created by Chandrashekhar (Chad) Kalnad on 10/9/2019
#I have used neural network for this problem
#I have used activation function for 1st layel as relu, hidden layers as tanh and final layel as sigmoid 
#I have used loss function as sparse categorial crossentropy and optimizer as adam as it fits well into the dataset and classes given
#The output is stored in final_output csv file


# In[1]:


#install anaconda and keras
get_ipython().system('conda install -c conda-forge keras --yes')
get_ipython().system('conda install -c conda-forge tensorflow --yes')
import keras; 

print(keras.__version__) 


# In[91]:


#import libraries
import numpy as np
from numpy import loadtxt
import csv
from keras.models import Sequential
from keras.layers import Dense
import pandas as pd


# In[92]:


#load the training data

#initialize dataframe
df = pd.read_csv("train.csv")

#convert dataframe to numpy array
dataset = df.to_numpy()

#split into input X and output y variables
X = dataset[0:7200,1:251]
Y = dataset[0:7200,251]


# In[93]:


#define model
model = Sequential()
model.add(Dense(300, input_dim = 250, activation='relu'))
model.add(Dense(250, activation = 'tanh'))
model.add(Dense(200, activation = 'tanh'))
model.add(Dense(150, activation = 'tanh'))
model.add(Dense(100, activation = 'tanh'))
model.add(Dense(50, activation = 'tanh'))
model.add(Dense(25, activation = 'tanh'))
model.add(Dense(5, activation='sigmoid'))


# In[94]:


#compile model
model.compile(loss='sparse_categorical_crossentropy', optimizer = 'adam', metrics=['accuracy'])


# In[95]:


#fit keras model on the dataset
model.fit(X, Y, epochs=150, batch_size=10)


# In[57]:


#evaluate the model
_, accuracy = model.evaluate(X,Y)
print('Accuracy: %2f' % (accuracy * 100))


# In[66]:


#load test data
#initialize dataframe
df = pd.read_csv("test.csv")

#convert dataframe to numpy array
dataset = df.to_numpy()

#split into input X and output y variables
x = dataset[0:4800,1:251]


# In[80]:


#make class predictions for train and test set
predictions_train = model.predict_classes(X)
predictions_test  = model.predict_classes(x)


# In[90]:


#write predictions to file

#write training predictions
df = pd.read_csv("train.csv")
df.drop(df.iloc[:, 1:252], inplace = True, axis = 1) 
df ['label'] = predictions_train
df.to_csv('final_output_train.csv', index = False)

#write test predictions
df = pd.read_csv("test.csv")
df.drop(df.iloc[:, 1:251], inplace = True, axis = 1) 
df ['label'] = predictions_test
df.to_csv('final_output_test.csv', index = False)

